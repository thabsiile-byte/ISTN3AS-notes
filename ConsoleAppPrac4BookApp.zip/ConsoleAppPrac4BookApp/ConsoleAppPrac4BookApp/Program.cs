﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppPrac4BookApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Book> books;
            GetBkFromDB(out books);
            OrderbyQOH(ref books);
            ShowBooks(books);
            Console.ReadLine();
            AddBook();
            GetBkFromDB(out books);
            OrderbyQOH(ref books);
            ShowBooks(books);
            Console.ReadLine();
        }
        static void GetBkFromDB(out List<Book> bks)
        {
            var bkContext = new BookContext();
            bks = bkContext.Books.ToList();
            
        }
        static void ShowBooks(List<Book> bks)
        {
            foreach (var item in bks)
            {
                item.ShowBook();
            }
        }
        public static void AddBook()
        {
            var bkContext = new BookContext();
            Book b1 = new Book() { Title = "Python", Type = "Programming", Cost = 300, QOH = 12 };
            Book b2 = new Book() { Title = "Visio Design Tools", Type = "Database Design", Cost = 100, QOH = 25 };
            bkContext.Books.Add(b1);
            bkContext.Books.Add(b2);
            bkContext.SaveChanges();
        }
        public static void OrderbyQOH(ref List<Book> bks)
        {
            bks = bks.OrderBy(bk => bk.QOH).ToList();
        }
    }
}
